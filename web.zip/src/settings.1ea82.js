window._CCSettings = {
    platform: "web-mobile",
    groupList: [
        "default",
        "magnifying"
    ],
    collisionMatrix: [
        [
            true
        ],
        [
            false,
            false
        ]
    ],
    hasResourcesBundle: true,
    hasStartSceneBundle: false,
    remoteBundles: [],
    subpackages: [],
    launchScene: "db://assets/scene/scene.fire",
    orientation: "landscape",
    debug: true,
    jsList: [
        "assets/plug/jszip.min.b5d02.js"
    ],
    bundleVers: {
        internal: "be8c4",
        bundle1: "fbf3f",
        resources: "0ef01",
        main: "c2cdf"
    }
};
